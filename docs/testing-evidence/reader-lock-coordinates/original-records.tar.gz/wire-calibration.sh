#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_NET_OFFLINE=true
receipts=/build/keep107-coordinate-evidence
source=/build/keep107-coordinate-source
cd /build/keep107-coordinate-driver-current
for file in intent_encoder.rs intent_semantic_header.rs; do cp "$receipts/$file.mutant" "$source/src/adapters/gc/$file"; done
CARGO_TARGET_DIR="$PWD/target" cargo build --locked --features typed
printf 'Correlated wire-slot mutation: seed=0x107c00d; expect successful codec calls but different bytes\n'
timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- target/debug/coordinate-observation "$receipts/wire-mutant.bin" 107c00d
set +e
cmp "$receipts/parent-fixed.bin" "$receipts/wire-mutant.bin"
observed=$?
set -e
printf 'Mutant comparison exit: %s\n' "$observed"
test "$observed" = 1
for file in intent_encoder.rs intent_semantic_header.rs; do cp "$receipts/$file.original" "$source/src/adapters/gc/$file"; done
CARGO_TARGET_DIR="$PWD/target" cargo build --locked --features typed
timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- target/debug/coordinate-observation "$receipts/wire-restored.bin" 107c00d
cmp "$receipts/parent-fixed.bin" "$receipts/wire-restored.bin"
printf 'Restored comparison exit: 0\n'
sha256sum "$receipts/wire-restored.bin"
