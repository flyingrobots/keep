#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_NET_OFFLINE=true
receipts=/build/keep107-coordinate-evidence
for subject in parent current; do
  directory=/build/keep107-coordinate-driver-$subject
  cd "$directory"
  cargo generate-lockfile --offline
  if test "$subject" = current; then
    cmp Cargo.lock /build/keep107-coordinate-driver-parent/Cargo.lock
    features=(--features typed)
  else
    features=()
  fi
  CARGO_TARGET_DIR="$directory/target" cargo build --locked "${features[@]}"
  printf 'Replay subject=%s seed=0x107c00d boundary-triples=7 generated-triples=256 address-space-cap=536870912 outer-deadline=30 network=unshare\n' "$subject"
  timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$directory/target/debug/coordinate-observation" "$receipts/$subject.bin"
done
cmp "$receipts/parent.bin" "$receipts/current.bin"
printf 'Exact runtime output comparison: identical\n'
sha256sum "$receipts/parent.bin" "$receipts/current.bin"
wc -c "$receipts/parent.bin" "$receipts/current.bin"
