//! Generated cross-revision observation of public codec bytes and coordinates.
use std::{error::Error, fs::File, io::Write};
use keep::{
    AdmittedGcRetirementIntent, AdmittedGcRetirementReceipt, AdmittedRecoveryDispositionReceipt,
    CanonicalGcRetirementIntent, CanonicalGcRetirementReceipt, CanonicalRecoveryDispositionReceipt,
    GcRetirementIntent, PoolStateDigest, ReaderLockIdentity, RecoveryDispositionReceipt,
};
#[cfg(feature = "typed")]
use keep::{ReaderLockDevice, ReaderLockFile, ReaderLockMount};

type Result<T> = std::result::Result<T, Box<dyn Error>>;

fn main() -> Result<()> {
    let destination = std::env::args_os().nth(1).ok_or("output path required")?;
    let mut output = File::create(destination)?;
    let intent_bytes = decode_hex(include_str!("fixtures/one-candidate-gc-intent.hex"))?;
    let disposition_bytes = decode_hex(include_str!("fixtures/one-orphan-retire-disposition.hex"))?;
    let intent = AdmittedGcRetirementIntent::decode(&intent_bytes)?;
    let disposition = AdmittedRecoveryDispositionReceipt::decode(&disposition_bytes)?;
    let boundaries = [
        [0, 0, 0], [u64::MAX, u64::MAX, u64::MAX], [0, 1, u64::MAX],
        [u64::MAX, 0, 1], [1, u64::MAX, 0],
        [u64::from(u32::MAX), 1_u64 << 32, (1_u64 << 32) + 1],
        [1_u64 << 63, (1_u64 << 63) - 1, (1_u64 << 63) + 1],
    ];
    for coordinates in boundaries {
        write_case(&mut output, coordinates, &intent, &disposition)?;
    }
    let seed = std::env::args().nth(2).ok_or("hexadecimal seed required")?;
    let mut state = u64::from_str_radix(&seed, 16)?;
    for _ in 0..256 {
        let coordinates = [next(&mut state), next(&mut state), next(&mut state)];
        write_case(&mut output, coordinates, &intent, &disposition)?;
    }
    output.sync_all()?;
    Ok(())
}

fn write_case(
    output: &mut File,
    raw: [u64; 3],
    source: &AdmittedGcRetirementIntent<'_>,
    disposition: &AdmittedRecoveryDispositionReceipt<'_>,
) -> Result<()> {
    let identity = identity(raw);
    let mut coordinates = *source.intent().coordinates();
    coordinates.reader_lock = identity;
    let value = GcRetirementIntent::new(coordinates, source.intent().candidates().to_vec())?;
    let intent = CanonicalGcRetirementIntent::from_intent(&value)?;
    let admitted = AdmittedGcRetirementIntent::decode(intent.encoded())?;
    write_record(output, intent.encoded(), admitted.intent().coordinates().reader_lock)?;
    let receipt = CanonicalGcRetirementReceipt::from_intent(&intent, PoolStateDigest::new([7; 32]));
    let admitted_receipt = AdmittedGcRetirementReceipt::decode(receipt.encoded(), &admitted)?;
    write_record(output, receipt.encoded(), admitted_receipt.receipt().reader_lock())?;
    let source = disposition.receipt();
    let mut coordinates = source.coordinates();
    coordinates.reader_lock = identity;
    let value = RecoveryDispositionReceipt::new(
        source.artifact(), source.decision(), coordinates, source.evidence_digest(),
    );
    let canonical = CanonicalRecoveryDispositionReceipt::from_receipt(&value);
    let admitted = AdmittedRecoveryDispositionReceipt::decode(canonical.encoded())?;
    write_record(output, canonical.encoded(), admitted.receipt().coordinates().reader_lock)
}

fn write_record(output: &mut File, bytes: &[u8], identity: ReaderLockIdentity) -> Result<()> {
    output.write_all(&u32::try_from(bytes.len())?.to_be_bytes())?;
    output.write_all(bytes)?;
    for coordinate in raw(identity) {
        output.write_all(&coordinate.to_be_bytes())?;
    }
    Ok(())
}

#[cfg(feature = "typed")]
fn identity([device, mount, file]: [u64; 3]) -> ReaderLockIdentity {
    ReaderLockIdentity::new(ReaderLockDevice::new(device), ReaderLockMount::new(mount), ReaderLockFile::new(file))
}
#[cfg(not(feature = "typed"))]
fn identity([device, mount, file]: [u64; 3]) -> ReaderLockIdentity {
    ReaderLockIdentity::new(device, mount, file)
}
#[cfg(feature = "typed")]
fn raw(identity: ReaderLockIdentity) -> [u64; 3] {
    [identity.device().get(), identity.mount().get(), identity.file().get()]
}
#[cfg(not(feature = "typed"))]
fn raw(identity: ReaderLockIdentity) -> [u64; 3] {
    [identity.device(), identity.mount(), identity.file()]
}

fn next(state: &mut u64) -> u64 {
    // Deliberate fixed-seed xorshift64, not ambient randomness or arithmetic overflow.
    *state ^= *state << 13;
    *state ^= *state >> 7;
    *state ^= *state << 17;
    *state
}
fn decode_hex(text: &str) -> Result<Vec<u8>> {
    let compact: String = text.chars().filter(|value| !value.is_whitespace()).collect();
    compact.as_bytes().chunks_exact(2).map(|pair| {
        Ok(u8::from_str_radix(std::str::from_utf8(pair)?, 16)?)
    }).collect()
}
