#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_NET_OFFLINE=true
receipts=/build/keep107-coordinate-evidence
extract=/build/keep107-coordinate-extracted
source=/build/keep107-coordinate-source
for subject in parent current; do
 cd "$extract/driver-$subject"
 cmp src/main.rs "$extract/driver.rs"
 sha256sum src/main.rs
 if test "$subject" = current; then features=(--features typed); else features=(); fi
 CARGO_TARGET_DIR=/build/keep107-coordinate-driver-$subject/target cargo build --locked "${features[@]}"
 cp /build/keep107-coordinate-driver-$subject/target/debug/coordinate-observation "$extract/driver-$subject.bin"
 timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$extract/driver-$subject.bin" "$extract/single-$subject.bin" 107c00d 0 1 0
 timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$extract/driver-$subject.bin" "$extract/full-$subject.bin" 107c00d
 cmp "$extract/full-$subject.bin" "$extract/parent-fixed.bin"
done
cmp "$extract/single-parent.bin" "$extract/single-current.bin"
sha256sum "$extract/single-parent.bin" "$extract/single-current.bin"
wc -c "$extract/single-parent.bin" "$extract/full-parent.bin"
restore() { for file in intent_encoder.rs intent_semantic_header.rs; do cp "$receipts/$file.original" "$source/src/adapters/gc/$file"; done; }
trap restore EXIT
for file in intent_encoder.rs intent_semantic_header.rs; do cp "$receipts/$file.mutant" "$source/src/adapters/gc/$file"; done
cd "$extract/driver-current"
CARGO_TARGET_DIR=/build/keep107-coordinate-driver-current/target cargo build --locked --features typed
cp /build/keep107-coordinate-driver-current/target/debug/coordinate-observation "$extract/driver-mutant.bin"
timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$extract/driver-mutant.bin" "$extract/single-mutant.bin" 107c00d 0 1 0
set +e
cmp "$extract/single-parent.bin" "$extract/single-mutant.bin"
observed=$?
set -e
printf 'Extracted single-triple mutation comparison exit: %s\n' "$observed"
test "$observed" = 1
restore
CARGO_TARGET_DIR=/build/keep107-coordinate-driver-current/target cargo build --locked --features typed
