#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_NET_OFFLINE=true
receipts=/build/keep107-coordinate-evidence
random_seed=$(cat "$receipts/random-seed.txt")
for subject in parent current; do
  directory=/build/keep107-coordinate-driver-$subject
  cd "$directory"
  cp Cargo.lock Cargo.preliminary.lock
  cp /build/keep107-coordinate-parent/Cargo.lock Cargo.lock
  if test "$subject" = current; then features=(--features typed); else features=(); fi
  CARGO_TARGET_DIR="$directory/target" cargo build --offline "${features[@]}"
  CARGO_TARGET_DIR="$directory/target" cargo build --locked "${features[@]}"
  if test "$subject" = current; then cmp Cargo.lock /build/keep107-coordinate-driver-parent/Cargo.lock; fi
  for corpus in fixed random; do
    if test "$corpus" = fixed; then seed=107c00d; else seed=$random_seed; fi
    printf 'Replay subject=%s corpus=%s seed=0x%s boundary-triples=7 generated-triples=256 address-space-cap=536870912 deadline=30 network=unshare\n' "$subject" "$corpus" "$seed"
    timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$directory/target/debug/coordinate-observation" "$receipts/$subject-$corpus.bin" "$seed"
  done
done
for corpus in fixed random; do
  cmp "$receipts/parent-$corpus.bin" "$receipts/current-$corpus.bin"
  printf 'Exact runtime output comparison %s: identical\n' "$corpus"
  sha256sum "$receipts/parent-$corpus.bin" "$receipts/current-$corpus.bin"
  wc -c "$receipts/parent-$corpus.bin" "$receipts/current-$corpus.bin"
done
