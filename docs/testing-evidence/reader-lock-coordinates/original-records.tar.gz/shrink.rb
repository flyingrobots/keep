# Reduce a failing runtime coordinate triple against two compiled public-API drivers.
require 'open3'
parent, candidate, directory, *values = ARGV
abort 'usage: shrink.rb parent candidate scratch device mount file' unless values.length == 3
abort 'scratch setup failed' unless system('docker', 'exec', 'keep-lawyer-138', 'mkdir', '-p', directory)
def differs(parent, candidate, directory, coordinates)
  [parent, candidate].each_with_index do |binary, index|
    output, status = Open3.capture2e('docker', 'exec', 'keep-lawyer-138', 'timeout', '--kill-after=5', '30', 'unshare', '-n', 'prlimit', '--as=536870912', '--', binary, "#{directory}/#{index}.bin", '107c00d', *coordinates.map(&:to_s))
    abort output unless status.success?
  end
_, status = Open3.capture2e('docker', 'exec', 'keep-lawyer-138', 'cmp', "#{directory}/0.bin", "#{directory}/1.bin")
abort 'comparison failed' unless [0, 1].include?(status.exitstatus)
status.exitstatus == 1
end
coordinates = values.map { |value| Integer(value, 10) }
abort 'input does not reproduce byte/coordinate divergence' unless differs(parent, candidate, directory, coordinates)
loop do
  changed = false
  3.times do |index|
    [0, coordinates[index] / 2, coordinates[index] - 1].uniq.select { |value| value >= 0 && value < coordinates[index] }.each do |value|
      trial = coordinates.dup
      trial[index] = value
      next unless differs(parent, candidate, directory, trial)
      coordinates = trial
      changed = true
      break
    end
  end
  break unless changed
end
puts "Reduced runtime counterexample: #{coordinates.join(',')}"
puts "Replay: #{candidate} #{directory}/replay.bin 107c00d #{coordinates.join(' ')}"
