#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_TARGET_DIR=/build/keep107-coordinate-target
cd /build/keep107-coordinate-source
receipts=/build/keep107-coordinate-evidence
cp src/adapters/gc/reader_lock_mount.rs "$receipts/mount-original.rs"
cp src/adapters/gc/reader_lock_file.rs "$receipts/file-original.rs"
for pair in device-mount device-file mount-file; do
  cp "$receipts/mount-original.rs" src/adapters/gc/reader_lock_mount.rs
  cp "$receipts/file-original.rs" src/adapters/gc/reader_lock_file.rs
  case "$pair" in
    device-mount) destination=mount; name=ReaderLockMount; alias=ReaderLockDevice; line=25 ;;
    device-file) destination=file; name=ReaderLockFile; alias=ReaderLockDevice; line=34 ;;
    mount-file) destination=file; name=ReaderLockFile; alias=ReaderLockMount; line=43 ;;
  esac
  printf '//! Calibration only: deliberately erase one coordinate distinction.\n/// Deliberately interchangeable calibration alias.\npub type %s = super::%s;\n' "$name" "$alias" > "src/adapters/gc/reader_lock_$destination.rs"
  printf 'Static/API calibration pair=%s expected unexpected compilation success at line=%s\n' "$pair" "$line"
  set +e
  timeout --kill-after=5 120 cargo test --locked --doc "reader_lock_identity::ReaderLockIdentity (line $line)" > "$receipts/$pair-red.txt" 2>&1
  observed=$?
  set -e
  printf 'Observed exit: %s\n' "$observed"
  test "$observed" = 101
  grep -F 'Test compiled successfully, but it' "$receipts/$pair-red.txt"
done
cp "$receipts/mount-original.rs" src/adapters/gc/reader_lock_mount.rs
cp "$receipts/file-original.rs" src/adapters/gc/reader_lock_file.rs
timeout --kill-after=5 120 cargo test --locked --doc reader_lock_identity > "$receipts/static-restored.txt" 2>&1
printf 'Restored distinct coordinate types: exit 0\n'
