#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_NET_OFFLINE=true
receipts=/build/keep107-coordinate-evidence
source=/build/keep107-coordinate-source
restore() { for file in intent_encoder.rs intent_semantic_header.rs; do cp "$receipts/$file.original" "$source/src/adapters/gc/$file"; done; }
trap restore EXIT
for file in intent_encoder.rs intent_semantic_header.rs; do cp "$receipts/$file.mutant" "$source/src/adapters/gc/$file"; done
cd /build/keep107-coordinate-driver-current
CARGO_TARGET_DIR="$PWD/target" cargo build --locked --features typed
cp target/debug/coordinate-observation "$receipts/coordinate-mutant"
restore
CARGO_TARGET_DIR="$PWD/target" cargo build --locked --features typed
