require 'open3'
require 'fileutils'
require 'digest'
$stdout.sync = true
repo, out, container, copy, start_at = ARGV
abort 'usage: calibrate.rb SOURCE OUTPUT CONTAINER COPIED_SOURCE' unless copy
FileUtils.mkdir_p(out)
controls = []
add = ->(name,path,old,new,targets,filter,witness) { controls << [name,path,old,new,targets,filter,witness] }
opaque_filter='resealed_opaque_coordinates_are_carried_into_a_distinct_intent'
header='src/adapters/gc/intent_header_decoder.rs'
[['manifest digest','manifest_digest',56],['catalog digest','catalog_digest',96],['catalog successor proof','catalog_successor_proof_digest',168],['segment pool identity','segment_pool_identity_digest',200],['disposition set','disposition_set_digest',232]].each do |name,field,offset|
 add.call(field,header,"#{field}: read_array(encoded, #{offset})?,","#{field}: [0; 32],",['gc_retirement_intent'],opaque_filter,"#{name} must retain the input coordinate")
end
[['device',264],['mount',272],['file',280]].each do |role,offset|
 add.call("reader_#{role}",header,"reader_#{role}: read_u64(encoded, #{offset})?,","reader_#{role}: 0,",['gc_retirement_intent'],opaque_filter,"reader lock #{role} must retain the input coordinate")
end
candidate='src/adapters/gc/intent_candidate_decoder.rs'
[['candidate_digest','SegmentDigest::from_validated(read_array(bytes, 0)?)','SegmentDigest::from_validated([0; 32])','candidate segment digest'],['candidate_length','let segment_length = read_u64(bytes, 32)?;','let segment_length = read_u64(bytes, 32)? ^ 1;','candidate segment length'],['candidate_evidence','VerificationEvidenceDigest::new(read_array(bytes, 40)?)','VerificationEvidenceDigest::new([0; 32])','candidate evidence digest']].each do |name,old,new,witness|
 add.call(name,candidate,old,new,['gc_retirement_intent'],opaque_filter,"#{witness} must retain the input coordinate")
end
frozen = [File.read(File.join(repo,'conformance/segment-store/v2/one-candidate-gc-intent.hex')).strip].pack('H*').bytes.slice(392,32).join(', ')
add.call('intent_identity','src/adapters/gc/admitted_intent.rs',"        self.digest\n", "        GcRetirementIntentDigest::from_hash([#{frozen}])\n",['gc_retirement_intent'],opaque_filter,'manifest digest must contribute to intent identity')
# These alter only the reported cause, leaving admission/refusal decisions intact.
[['gc/generation','GcGenerationError',['gc_retirement_intent'],'GC generation zero'],['catalog/generation','CatalogGenerationError',['gc_retirement_intent'],'catalog generation zero'],['retention/liveness_generation','LivenessGenerationError',['gc_retirement_intent','retention_head_codec','retention_manifest_codec'],'liveness generation zero'],['retention/root_generation','RootGenerationError',['retention_root_decoding','retention_manifest_codec'],'generation zero']].each do |path,error,targets,witness|
 add.call(error,"src/#{path}.rs","None => Err(#{error}::Zero)","None => Err(#{error}::Exhausted { current: 0 })",targets,'malformed_',witness)
end
add.call('intent_magic',header,'Error::InvalidMagic { observed: magic }','Error::InvalidMagic { observed: [0; 16] }',['gc_retirement_intent'],'malformed_','magic refused')
profile='src/retention/profile.rs'
add.call('profile_identity',profile,'observed_identity: identity,','observed_identity: 0,',['gc_retirement_intent','retention_root_decoding'],'malformed_','profile identity refused')
# Preserve the identity-error version, so execution reaches the version row.
add.call('profile_version',profile,'observed_version: version,','observed_version: if identity == 1 { 0 } else { version },',['gc_retirement_intent','retention_root_decoding'],'malformed_','profile version refused')
add.call('profile_digest',profile,"expected: expected.digest,\n                observed: digest,","expected: digest,\n                observed: expected.digest,",['gc_retirement_intent','retention_root_decoding'],'malformed_','profile-definition digest refused')
receipt='src/adapters/gc/receipt_decoder.rs'
[['Mount',5],['File',6]].each do |role,value|
 old="                coordinate,\n                expected,\n                observed,"
 new="                coordinate,\n                expected: if coordinate == ReaderLockCoordinate::#{role} { 0 } else { expected },\n                observed,"
 add.call("receipt_#{role}",receipt,old,new,['gc_retirement_receipt'],'malformed_',"reader-lock #{role.downcase} refused")
end
[['IntentDigestMismatch','intent digest'],['RetiredSetDigestMismatch','retired candidate-set digest'],['ManifestDigestMismatch','retention-manifest digest'],['CatalogDigestMismatch','catalog digest']].each do |variant,witness|
 add.call("receipt_#{variant}",receipt,"Error::#{variant} { expected, observed }","Error::#{variant} { expected: observed, observed: expected }",['gc_retirement_receipt'],'malformed_',"#{witness} refused")
end
limits='src/retention/closure_limits.rs'
[['Nodes','closure-node limit zero'],['EncodedBytes','encoded-byte limit zero'],['PhysicalBytes','physical-byte limit zero']].each do |limit,witness|
 add.call("limit_#{limit}",limits,'RetentionClosureLimitError::Zero { limit }',"RetentionClosureLimitError::Zero { limit: if limit == RetentionClosureLimit::#{limit} { RetentionClosureLimit::Depth } else { limit } }",['retention_root_decoding'],'malformed_',"#{witness} refused")
end
add.call('limit_depth',limits,'maximum: u64::from(RetentionClosureLimits::MAXIMUM_DEPTH),','maximum: 7,',['retention_root_decoding'],'malformed_','closure-depth limit above ceiling refused')
length='src/retention/manifest_length.rs'
add.call('length_bounds',length,'minimum: MINIMUM_VALUE,','minimum: 223,',['retention_head_codec'],'malformed_','manifest length below bound refused')
add.call('length_congruence',length,'RetentionManifestLengthError::NotCongruent { observed: value }','RetentionManifestLengthError::NotCongruent { observed: 224 }',['retention_head_codec'],'malformed_','manifest length not congruent refused')
controls = controls.drop_while { |control| control.first != start_at } if start_at
abort 'no matching controls' if controls.empty?
controls.each do |name,path,old,new,targets,filter,witness|
 original = File.binread(File.join(repo,path))
 abort "missing mutation subject #{name}" unless original.include?(old)
 changed=original.sub(old,new)
 original_path=File.join(out,"#{name}.original")
 mutant_path=File.join(out,"#{name}.mutant")
 File.binwrite(original_path,original); File.binwrite(mutant_path,changed)
 puts "CONTROL #{name} source=#{path} sha256=#{Digest::SHA256.hexdigest(original)} witness=#{witness}"
 begin
  system('docker','cp',mutant_path,"#{container}:#{copy}/#{path}",exception:true)
  system('docker','exec',container,'touch',"#{copy}/#{path}",exception:true)
  targets.each do |target|
   command=['docker','exec','-w',copy,container,'env','PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','CARGO_TARGET_DIR=/build/keep107-coordinate-target','CARGO_NET_OFFLINE=true','cargo','test','--locked','--test',target,filter,'--','--nocapture']
   output,status=Open3.capture2e(*command)
   File.write(File.join(out,"#{name}-#{target}.txt"),output)
   abort "not assertion RED: #{name}/#{target} exit=#{status.exitstatus}" unless status.exitstatus==101 && output.include?(witness) && output.include?('test result: FAILED') && !output.include?('could not compile')
   puts "ASSERTION RED #{name}/#{target} exit=101 witness=#{witness}"
  end
 ensure
  system('docker','cp',original_path,"#{container}:#{copy}/#{path}",exception:true)
  system('docker','exec',container,'touch',"#{copy}/#{path}",exception:true)
 end
end
puts 'All selected runtime controls failed at their intended assertions; production sources restored.'
