#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_TARGET_DIR=/build/keep107-coordinate-target CARGO_NET_OFFLINE=true
cd /build/keep107-coordinate-source
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
cargo clippy --workspace --all-targets --no-default-features --locked -- -D warnings
for profile in debug release; do
  if test "$profile" = release; then mode=(--release); else mode=(); fi
  cargo test --locked "${mode[@]}" --test gc_retirement_intent --test gc_retirement_receipt --test retention_root_decoding --test retention_head_codec --test retention_manifest_codec
done
