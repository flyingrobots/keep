#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR=/build/keep107-coordinate-target
cd /build/keep107-coordinate-source
scratch=/build/keep107-provenance
mkdir -p "$scratch"
rustc -Vv
cargo -Vv
b3sum --version
for name in one-candidate-gc-intent one-candidate-gc-receipt; do
 perl -0ne 's/\s+//g; /\A(?:[0-9a-fA-F]{2})*\z/ or die "invalid fixture hex"; print pack "H*", $_;' "conformance/segment-store/v2/$name.hex" > "$scratch/$name.bin"
done
intent=$scratch/one-candidate-gc-intent.bin
receipt=$scratch/one-candidate-gc-receipt.bin
check_digest() {
 local name=$1 actual=$2 stored=$3
 printf '%s\n' "$actual" > "$scratch/$name.actual"
 printf '%s\n' "$stored" > "$scratch/$name.stored"
 printf '%s computed=%s stored=%s\n' "$name" "$actual" "$stored"
 cmp "$scratch/$name.actual" "$scratch/$name.stored"
}
hex_at() { dd if="$1" bs=1 skip="$2" count=32 status=none | od -An -v -tx1 | tr -d ' \n'; }
check_digest candidate-set "$({ printf 'keep.gc-candidate-set/v2\0'; dd if="$intent" bs=1 skip=44 count=4 status=none; dd if="$intent" bs=1 skip=320 count=72 status=none; } | b3sum --no-names)" "$(hex_at "$intent" 288)"
check_digest intent "$({ printf 'keep.gc-retirement-intent/v2\0'; dd if="$intent" bs=1 count=392 status=none; } | b3sum --no-names)" "$(hex_at "$intent" 392)"
check_digest intent-checksum "$({ printf 'keep.gc-retirement-intent-checksum/v2\0'; dd if="$intent" bs=1 count=424 status=none; } | b3sum --no-names)" "$(hex_at "$intent" 424)"
check_digest receipt-checksum "$({ printf 'keep.gc-retirement-receipt-checksum/v2\0'; dd if="$receipt" bs=1 count=288 status=none; } | b3sum --no-names)" "$(hex_at "$receipt" 288)"
{ printf 'keep.retention-realization-profile/v1\0'; cat conformance/segment-store/v2/retention-profile.tsv; } | b3sum --no-names
{ printf 'keep.segment-store-definition/v2\0'; cat conformance/segment-store/v2/definition.tsv; } | b3sum --no-names
sha256sum conformance/segment-store/v2/one-candidate-gc-intent.hex conformance/segment-store/v2/one-candidate-gc-receipt.hex
for profile in debug release; do
 if test "$profile" = release; then mode=(--release); else mode=(); fi
 timeout --kill-after=5 120 cargo test --locked "${mode[@]}" -p xtask --test retention_store_v2_format_oracle golden_artifacts_match_the_independent_oracle
 timeout --kill-after=5 120 cargo test --locked "${mode[@]}" --test gc_retirement_intent --test gc_retirement_receipt
 done
