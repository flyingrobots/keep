#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin CARGO_NET_OFFLINE=true CARGO_TARGET_DIR=/build/keep107-coordinate-target
cd /build/keep107-coordinate-source
# The copied archive lacks Git metadata. The structure checker queries an index;
# create only a local inspection index, with no product commit or remote claim.
git init -q --initial-branch=evidence
git add --all
cargo run --locked -p xtask -- source-structure-check
