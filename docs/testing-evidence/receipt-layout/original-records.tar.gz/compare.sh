#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin CARGO_NET_OFFLINE=true
receipts=/build/keep107-receipt-evidence
random_seed=$(cat "$receipts/random-seed.txt")
for subject in parent current; do
 directory=/build/keep107-receipt-driver-$subject
 cd "$directory"
 export CARGO_TARGET_DIR=/build/keep107-coordinate-driver-$subject/target
 cargo build --offline --features typed
 cargo build --locked --features typed
 cp "$CARGO_TARGET_DIR/debug/coordinate-observation" "$receipts/driver-$subject"
 if test "$subject" = current; then cmp Cargo.lock /build/keep107-receipt-driver-parent/Cargo.lock; fi
 for corpus in fixed random; do
  if test "$corpus" = fixed; then seed=107c00d; else seed=$random_seed; fi
  printf 'Replay subject=%s corpus=%s seed=0x%s cases=7+256 deadline=30 kill-grace=5 address-space=536870912 network=unshare\n' "$subject" "$corpus" "$seed"
  timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$receipts/driver-$subject" "$receipts/$subject-$corpus.bin" "$seed"
 done
done
for corpus in fixed random; do
 cmp "$receipts/parent-$corpus.bin" "$receipts/current-$corpus.bin"
 printf 'Exact sampled public output comparison %s: equal\n' "$corpus"
 sha256sum "$receipts/parent-$corpus.bin" "$receipts/current-$corpus.bin"
 wc -c "$receipts/parent-$corpus.bin" "$receipts/current-$corpus.bin"
done
