#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CARGO_TARGET_DIR=/build/keep107-coordinate-target
export TMPDIR=/audit/keep107-coordinate-source-scratch
export CARGO_NET_OFFLINE=true
cd /build/keep107-coordinate-source
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
cargo clippy --workspace --all-targets --no-default-features --locked -- -D warnings
cargo test --doc reader_lock_identity
for profile in debug release; do
  if test "$profile" = release; then mode=(--release); else mode=(); fi
  printf 'Focused profile=%s\n' "$profile"
  cargo test --locked "${mode[@]}" --test gc_retirement_intent --test gc_retirement_receipt --test recovery_disposition_receipt
  cargo test --locked "${mode[@]}" --lib adapters::gc::
  cargo test --locked "${mode[@]}" --lib filesystem_retention_disposition_tests
  cargo test --locked "${mode[@]}" -p xtask --test retention_store_v2_format_oracle
 done
cargo clippy --locked --manifest-path fuzz/Cargo.toml --bin gc_format -- -D warnings
cargo run --locked -p xtask -- source-structure-check
