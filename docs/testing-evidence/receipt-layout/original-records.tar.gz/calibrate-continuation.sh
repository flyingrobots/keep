#!/usr/bin/env bash
set -euo pipefail
export PATH=/tools/bin:/usr/local/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin CARGO_NET_OFFLINE=true
receipts=/build/keep107-receipt-evidence
source=/build/keep107-coordinate-source
restore() { cp "$receipts/encoder.original" "$source/src/adapters/gc/receipt_encoder.rs"; cp "$receipts/format.original" "$source/src/adapters/gc/receipt_format.rs"; }
trap restore EXIT
cd "$source"
for control in record-length; do
 restore
 case "$control" in field-array|field-total) destination=receipt_encoder.rs ;; *) destination=receipt_format.rs ;; esac
 cp "$receipts/$control.mutant" "src/adapters/gc/$destination"
 printf 'Static layout control=%s expected compiler rejection\n' "$control"
 set +e
 CARGO_TARGET_DIR=/build/keep107-coordinate-target timeout --kill-after=5 120 cargo check --lib --locked > "$receipts/$control.txt" 2>&1
 observed=$?
 set -e
 printf 'Compiler exit=%s\n' "$observed"
 test "$observed" = 101
 case "$control" in record-length) grep -F 'error[E0080]' "$receipts/$control.txt" ;; *) grep -F 'error[E0308]' "$receipts/$control.txt" ;; esac
 done
restore
CARGO_TARGET_DIR=/build/keep107-coordinate-target cargo check --lib --locked
cp "$receipts/pool-runtime.mutant" src/adapters/gc/receipt_encoder.rs
cd /build/keep107-receipt-driver-current
export CARGO_TARGET_DIR=/build/keep107-coordinate-driver-current/target
cargo build --locked --features typed
cp "$CARGO_TARGET_DIR/debug/coordinate-observation" "$receipts/driver-mutant"
printf 'Runtime pool-retention control seed=0x107c00d\n'
timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$receipts/driver-mutant" "$receipts/pool-mutant.bin" 107c00d
set +e
cmp "$receipts/parent-fixed.bin" "$receipts/pool-mutant.bin"
observed=$?
set -e
printf 'Runtime comparison exit=%s\n' "$observed"
test "$observed" = 1
restore
cargo build --locked --features typed
cp "$CARGO_TARGET_DIR/debug/coordinate-observation" "$receipts/driver-restored"
timeout --kill-after=5 30 unshare -n prlimit --as=536870912 -- "$receipts/driver-restored" "$receipts/restored.bin" 107c00d
cmp "$receipts/parent-fixed.bin" "$receipts/restored.bin"
printf 'Restored runtime comparison: equal\n'
sha256sum "$receipts/restored.bin"
